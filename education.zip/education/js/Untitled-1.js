<!DOCTYPE html>
 <html>

<head>
    <script>
var a=100;
var b;

b = "Value is " + (a > 100 ? "True" : "False");


document.write(b);
    </script>
</head>
<body>

</body>

    </html>